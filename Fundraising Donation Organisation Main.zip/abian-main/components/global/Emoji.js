const emoji = {};
emoji.loading = "🙂";
emoji.success = "😊";
emoji.error = "😖";

export default emoji;
