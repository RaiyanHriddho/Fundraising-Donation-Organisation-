const MessageModal = () => {
  return <div>Message Modal</div>;
};

export default MessageModal;
