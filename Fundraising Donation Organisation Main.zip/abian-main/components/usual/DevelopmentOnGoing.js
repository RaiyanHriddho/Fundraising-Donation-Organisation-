const DevelopmentOnGoing = () => {
    return (
        <div style={{ height: "600px", display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", flexWrap: "nowrap" }} className="section container">
            <button className="btn-warning">Warning! This site is under developement</button>

            <button className="btn-success" style={{ marginTop: "10px" }}>Developed by {"Coder's"} Hub</button>
            <br />
            <ul>
                <li>Ataur Rahman <br /> (Jr. Software Engr. at Avalon)</li>
                <li>Musiur Alam Opu <br /> (Jr. Software Engr. at Avalon)</li>
                <li>Minul Islam Tareq</li>
                <li>A S Ahsan</li>
            </ul>
        </div>
    )
}


export default DevelopmentOnGoing;