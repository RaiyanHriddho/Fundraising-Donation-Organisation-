const express = require("express");
const {
  donation_list,
  donation_create,
  donation_update,
  donation_delete,
} = require("../controllers/donation_list.controller");
const router = express.Router();

router.get("/donation/list", donation_list);
router.post("/donation/create", donation_create);
router.put("/donation/update", donation_update);
router.delete("/donation/delete", donation_delete)

module.exports = router;
