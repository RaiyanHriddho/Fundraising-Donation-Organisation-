exports.test = (req, res) => {
  res.send("Hello world!");
};
