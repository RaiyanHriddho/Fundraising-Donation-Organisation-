const DB = require("../database");


exports.donation_create = (req, res) => {
  const {name, location, contact_number, transaction_id, amount, payment_method, donar_id, event_id} = req.body;
  DB.query(
    `insert into donation_list set ?`,
    {
      name,
      location,
      contact_number,
      transaction_id,
      amount, 
      member_type: "silver", 
      payment_method, 
      progress: "pending",
      created_at: new Date(),
      donar_id,
      event_id
    },
    (err1, result1) => {
      // insertion status checking
      if (!err1) {
        console.log(result1);
        return res.status(200).send({
          message: "New donation info added to list successfully!",
        });
      } else {
        console.log("Error", err1 );
        return res.status(500).send({
          message: "Something went wrong!",
        });
      }
    }
  );
};

exports.donation_list = (req, res) => {
  DB.query("select * from donation_list", async (err, result) => {
    if (!err) {
      if (result.length) {
        return res.status(200).send({
          message: "Donation fetched Successfully!",
          result,
        });
      } else {
        return res.status(404).send({
          message: "No donation found!",
        });
      }
    } else {
      return res.status(500).send({
        message: "Something went wrong!",
      });
    }
  });
};



exports.donation_update = (req, res) => {
  const {transaction_id, updated_data} = req.body;
  DB.query(
    `update donation_list set ? where transaction_id="${transaction_id}"`,
    {
      ...updated_data
    },
    (err1, result1) => {
      // insertion status checking
      if (!err1) {
        console.log(result1);
        return res.status(200).send({
          message: `Donation info updated successfully of ! ${transaction_id}`,
        });
      } else {
        console.log("Error", err1 );
        return res.status(500).send({
          message: "Something went wrong!",
        });
      }
    }
  );
};

exports.donation_delete = (req, res) => {
  const {id} = req.query;
  console.log(id)
  DB.query(
    `delete from donation_list where id="${id}"`,
    (err1, result1) => {
      // insertion status checking
      if (!err1) {
        console.log(result1);
        return res.status(200).send({
          message: `Donation info deleted successfully of ! ${id}`,
        });
      } else {
        console.log("Error", err1 );
        return res.status(500).send({
          message: "Something went wrong!",
        });
      }
    }
  );
};
